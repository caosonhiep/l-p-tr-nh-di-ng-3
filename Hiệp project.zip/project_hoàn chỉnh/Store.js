import { createStore } from 'redux'
import contacts from './Reducer'

export default store = createStore(contacts)